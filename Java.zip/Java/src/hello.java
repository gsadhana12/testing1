
public class hello {
public static void main(String[] args)
{
System.out.println("HELLO  karthik ");
int myfirstnumber = (10+5);
int mysecondnumber = 5;
int mythirdnumber = 6;
int myfourthnumber=90;
int mytotal = myfirstnumber+mysecondnumber+mythirdnumber+myfourthnumber;
System.out.println(mytotal);
System.out.println("mytotal is applicable here  ");
System.out.println(mythirdnumber);
System.out.println(1000-mytotal);
System.out.println(mytotal-myfourthnumber);
int myintegervalue = 5;
float myfloatvalue=5f/3;
double mydoublevalue=5d;
System.out.println("myintegervalue="+myintegervalue);
System.out.println("myfloatvalue="+myfloatvalue);
System.out.println("mydoublevalue="+mydoublevalue);
double pounds = 155.6;
double kilogram= 155.6*0.4535;
System.out.println(kilogram);




  
}
}  