
public class Methods {
	
	public void ValidationHeader() {
		System.out.println("This is a validated");
	}
	
	// method with returning value
	
	public String ValidationHeader2() {
		
		System.out.println("This is validated again");
		 return "pass";
		
	}

}
