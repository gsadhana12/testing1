
public class Basics {
	
	public static void main(String[] args) {
		
		//System.out.println("Learning Basic java");
		
		//int a = 10;
		//int b = 12;
		//nt sum = a+b;
		//System.out.println("Sum is"+ sum);
		
	//We are creating or calling other class in main class by writing instance for it
		
		Methods m = new Methods();
		m.ValidationHeader();
		
	//M is the object for class methods and new allocate space for methods class
		//Calling another method from methods class
		
		System.out.println(m.ValidationHeader2());
	}

}
